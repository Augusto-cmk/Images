from pathlib import Path
import importlib
import pkgutil
from typer import echo

__all__ = []

package_dir = Path(__file__).parent

for module in pkgutil.iter_modules([str(package_dir)]):

    module_name = module.name

    if module_name.startswith("_"):
        continue

    if not module.ispkg:
        continue

    try:

        mod = importlib.import_module(
            f"{__name__}.{module_name}"
        )

        if hasattr(mod, "app"):

            globals()[module_name] = mod.app

            __all__.append(module_name)

    except Exception as e:
        echo(f"Error for load {module_name}: {e}")