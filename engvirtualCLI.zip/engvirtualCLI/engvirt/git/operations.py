from . import app,typer
from engvirt.dependency import require
from engvirt.config.base import Config
from rich import print
from rich.markdown import Markdown

config = Config()

@app.command()
def doc(repository: str, verify: str = typer.Option(None,"--verify"), branch: str = typer.Option(None,'-b'), show: bool = typer.Option(False,'--show')):
    require("github",pip_name="pygithub")
    from github import Github

    token = config['git']['token']
    if token is None:
        typer.echo("Your token can't configured, please configure your token. Use 'engvirt git auth --help' for search how to do this")
    
    try:
        if verify:
            git = Github(token,verify=verify)
        else:
            git = Github(token)
    except AssertionError as e:
        typer.echo("Authentication fail for your auth configuration, please verify if your configuration auth it's okey.")
        return

    repo = git.get_repo(repository)
    readme = repo.get_readme().decoded_content.decode()
    if branch:
        version = repo.get_branch(branch)

    if show:
        typer.echo(f"This is the documentation for {repository}:\n")
        print(Markdown(readme))