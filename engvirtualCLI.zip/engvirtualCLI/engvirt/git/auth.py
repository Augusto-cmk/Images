from engvirt.config.base import Config
from . import app,typer

config = Config()

@app.command()
def auth(token: str = typer.Option(None,"--token"), show: bool = typer.Option(False, "--show")):
    """
    Authentication method for use on github call's. You can see the authentication alread defined if you want.

    Arguments:
        - token: str = String of your token (optional)
        - '--show': bool = Show your token
    """
    if show:
        typer.echo(config["git"]["token"])
        return
    config['git']['token'] = token
    config.save()