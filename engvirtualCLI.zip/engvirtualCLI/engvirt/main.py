import typer
import engvirt

app = typer.Typer()

for name in engvirt.__all__:
    app.add_typer(
        getattr(engvirt, name),
        name=name
    )

def main():
    app()

if __name__ == "__main__":
    main()