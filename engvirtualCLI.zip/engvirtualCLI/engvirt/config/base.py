from pathlib import Path
from json import load, dump
import sys


class Config(dict):
    _instance = None
    DIR = Path(sys.prefix) / ".engvirt"
    FILE = DIR / "config.json"
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if hasattr(self, "_initialized"):
            return

        self._initialized = True
        self.DIR.mkdir(parents=True, exist_ok=True)
        try:
            with open(self.FILE, "r") as file:
                data = load(file)
        except Exception:
            data = {}

        super().__init__(data)

    def save(self):

        with open(self.FILE, "w") as file:
            dump(dict(self), file, indent=4)