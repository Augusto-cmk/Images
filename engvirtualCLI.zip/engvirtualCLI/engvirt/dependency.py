import importlib.util
import subprocess
import sys
import typer


def require(package, pip_name=None):
    if importlib.util.find_spec(package) is None:

        pip_name = pip_name or package

        typer.echo(
            f"Installing dependency: {pip_name}"
        )

        subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                pip_name
            ],
            check=True
        )